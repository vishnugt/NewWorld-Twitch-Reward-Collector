# AutoRewardCollector

This chrome extension collects the materials given while watching New World MMORPG stream
Please feel free to send PRs.

# Instructions for installing this chrome extension:

-> Download this repo or clone this repo<br />
-> From Chrome/Edge -> Menu (3 dots in upper right corner)-> More tools-> Extensions<br />
-> Enable "Developer mode", then select “Load unpacked" and browse to the directory where you have downlaoded this repo.<br />